public class JavaStrings {
    public static void main(String[] args){
        String ninja = "Coding Dojo is Awesome";
        int length = ninja.length();
        System.out.println("String length is : " + length);
    }
}