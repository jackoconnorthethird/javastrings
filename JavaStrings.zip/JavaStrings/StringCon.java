public class StringCon {
     public static void main(String[] args){
    //     String string1 = "My name is ";
    //     String string2 = "Jack";
    //     String string3 = string1.concat(string2);
    //     //or////
    //     String ninja = String.format("Hi, %s, you owe me $%.2f !", "Jack", 25.0);
    //     System.out.println(ninja);
    // }
    
    //IndexOf//
    // public static void indexof(String[] args){
        // String ninja1 = "welcome to coding dojo";
        // int a = ninja1.indexOf("Coding");
        // int b = ninja1.indexOf("co");
        // int c = ninja1.indexOf("pizza");
        // System.out.println(c);
        ///will get -1///"pizz is not found"//
    
    //trim//
    // String sentence = "   spaces everywhere!   ";
    // System.out.println(sentence.trim());

    //upper case and lower case//    
    // String a = "hello";
    // String b = "world";
    // System.out.println(a.toLowerCase()); // hello
    // System.out.println(b.toUpperCase()); // WORLD
    
    //equality//
    String a = new String("word");
    String b = new String("word");
    System.out.println(a == b); // false. not the same exact object.
    System.out.println(a.equals(b)); // true. same exact characters.
    
}


}